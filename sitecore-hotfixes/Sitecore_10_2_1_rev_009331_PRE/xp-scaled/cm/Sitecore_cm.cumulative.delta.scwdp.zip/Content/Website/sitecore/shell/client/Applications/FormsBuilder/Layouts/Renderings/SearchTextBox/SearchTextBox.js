(function (Speak) {
    Speak.component(["/-/speak/v1/components/ButtonTextBox.js"], function () {
        var onUserInput = _.debounce(function () {
            if (this.TriggerTextChangeOnKeyUp) {
                this.Value = inputDomEl.value;
            }
        }, 400);
        var inputDomEl;
        return Speak.extend(Speak.component("ButtonTextBox")(), {

            initialized: function () {
                inputDomEl = this.el.querySelector("input");
                inputDomEl.addEventListener("keypress", this.keyupPressed.bind(this));
                this.on("change:Value", this.setText.bind(this));
                this.defineComputedProperty("SearchQuery", function () {
                    return this.Value.replace(/ /g, "+");
                });
            },
        })
    }, "SearchTextBox");
})(Sitecore.Speak);
